#include "labfive.h"

#include <iostream>
#include <iomanip>
#include <sstream>

using std::cout;
using std::endl;
using std::stringstream;
using std::setw;
using std::setprecision;
using std::fixed;


int main(int argc, char* argv[]){

	const float TOTAL_PASSED = 13;
	const float TOTAL_MATCHED = 7;
	const float TOTAL_XPASSED = 10;
	const float TOTAL_XMATCHED = 3;

	size_t passed = 0, xpassed=0, matched = 0, xmatched = 0;

	// Test Add Arrays
	int a[] = {7, 3, 4}, b[] = {1, 0, -5}, c[sizeof(a)/sizeof(a[0])];
	int r[] = {8, 3, -1};
	AddArrays(a, b, c, sizeof(a)/sizeof(a[0]));
	bool ok = true;
	for (size_t i = 0; i < sizeof(a)/sizeof(a[0]); i++) {
		if (c[i] == r[i]){
			cout << "Position " << i << " matched" << endl;
			matched++;
		}else{
			cout << "Position " << i << " did not matched" << endl;
			ok = false;
		}
	}
	if (!ok){
		cout << "-----> AddArray failed" << endl;
	}else{
		cout << "-----> AddArray passed" << endl;
		passed++;
	}


	if (IsPalindrome("car")){
		cout << "-----> IsPalindrome(\"car\") failed" << endl;
	}else{
		cout << "-----> IsPalindrome(\"car\") passed" << endl;
		passed++;
	}

	if (!IsPalindrome("adogoda")){
		cout << "-----> IsPalindrome(\"adogoda\") failed" << endl;
	}else{
		cout << "-----> IsPalindrome(\"adogoda\") passed" << endl;
		passed++;
	}

	unsigned short int data[] = {1, 3, 1, 4, 5, 3, 4};
	unsigned short int key[] = {1, 3, 4, 5};
	unsigned short int result[sizeof(data) / sizeof(data[0])];
	size_t nonDuplicates;
	nonDuplicates = RemoveDuplicates(data, result, sizeof(data) / sizeof(data[0]));

	if (nonDuplicates == 4){
		cout << "-----> RemoveDuplicates return passed" << endl;
		passed++;
		ok = true;
		for (size_t i = 0; i < nonDuplicates; i++) {
			if (key[i] == result[i]){
				cout << "Position " << i << " matched" << endl;
				matched++;
			}else{
				cout << "Position " << i << " did not matched" << endl;
				ok = false;
			}
		}
		if (!ok){
			cout << "-----> RemoveDuplicates elements failed" << endl;
		}else{
			cout << "-----> RemoveDuplicates elements passed" << endl;
			passed++;
		}

	}else{
		cout << "-----> RemoveDuplicates return failed" << endl;
	}

	stringstream stats, computers;
	ok = PrintStats("testfile.txt", stats);
	if (!ok){
		cout << "-----> PrintStats return failed" << endl;
	}else{
		cout << "-----> PrintStats return passed" << endl;
		passed++;
	}
	int characters, nonWhitespaces, digits, punctuation;
	stats >> characters >> nonWhitespaces >> digits >> punctuation;
	if (characters == 249){
		cout << "-----> Characters Count return passed" << endl;
		passed++;
	}else{
		cout << "-----> Characters Count return failed" << endl;
	}

	if (nonWhitespaces == 190){
		cout << "-----> Non Whitespaces Count return passed" << endl;
		passed++;
	}else{
		cout << "-----> Non Whitespaces Count return failed" << endl;
	}

	if (digits == 3){
		cout << "-----> Digits Count return passed" << endl;
		passed++;
	}else{
		cout << "-----> Digits Count return failed" << endl;
	}

	if (punctuation == 8){
		cout << "-----> Punctuation Count return passed" << endl;
		passed++;
	}else{
		cout << "-----> Punctuation Count return failed" << endl;
	}


	ok = PrintStats("notfound", cout);
	if (ok){
		cout << "-----> PrintStats file not found failed" << endl;
	}else{
		cout << "-----> PrintStats file not found passed" << endl;
		passed++;
	}

	const unsigned long int GIGA = 1024 * 1024 * 1024;
	Computer machines[] = {
		{"Dell", "Optiplex", 2500000000, 8 * GIGA, 250 * GIGA},
		{"Apple", "MacAir", 1750000000, 4 * GIGA, 128 * GIGA},
		{"Lenovo", "T450", 2333000000, 6 * GIGA, 256 * GIGA},
		{"Dell", "Inspiron", 3000000000, 16 * GIGA, 256 * GIGA},
		{"HAL", "9000", 45000000000, 512 * GIGA, 2500 * 1024 * GIGA},
		{"SAL","9000",65000000000, 2048 * GIGA, 4800 * 1024 * GIGA},
		{"Dell","Dimension",3500000000, 32 * GIGA, 2 * 1024 * GIGA}};

	PrintComputers(machines, sizeof(machines) / sizeof(machines[0]), cout);

	size_t max = MaxSpeed(machines, sizeof(machines) / sizeof(machines[0]));
	size_t min = MinMemory(machines, sizeof(machines) / sizeof(machines[0]));

	if (max == 5){
		cout << "-----> MaxSpeed passed" << endl;
		passed++;
	}else{
		cout << "-----> MaxSpeed failed" << endl;
	}

	if (min == 1){
		cout << "-----> MinMemory passed" << endl;
		passed++;
	}else{
		cout << "-----> MinMemory failed" << endl;
	}
	cout << endl << "= = = = = = = = = = = = = = = = = = = = = = = =" << endl;
	cout << "Passed  " << fixed << setprecision(2) << passed / TOTAL_PASSED * 100 << endl;
	cout << "Matched " << fixed << setprecision(2) << matched / TOTAL_MATCHED * 100 << endl;
	cout << "= = = = = = = = = = = = = = = = = = = = = = = =" << endl << endl;

	// Extra Credit Operations

	Sort(machines, sizeof(machines) / sizeof(machines[0]));
	PrintComputers(machines, sizeof(machines) / sizeof(machines[0]), cout);

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "Dell", "Optiplex") == 3){
		cout << "-----> Binary Search Test 1 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 1 failed" << endl;
	}
	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "Apple", "MacAir") == 0){
		cout << "-----> Binary Search Test 2 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 2 failed" << endl;
	}

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "Lenovo", "T450") == 5){
		cout << "-----> Binary Search Test 3 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 3 failed" << endl;
	}

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "Dell", "Inspiron") == 2){
		cout << "-----> Binary Search Test 4 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 4 failed" << endl;
	}

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "HAL", "9000") == 4){
		cout << "-----> Binary Search Test 5 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 5 failed" << endl;
	}

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "SAL", "9000") == 6){
		cout << "-----> Binary Search Test 6 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 6 failed" << endl;
	}

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "Dell", "Dimension") == 1){
		cout << "-----> Binary Search Test 7 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 7 failed" << endl;
	}

	if (BinarySearch(machines, sizeof(machines) / sizeof(machines[0]), "Apple", "MacBookPro") == -1){
		cout << "-----> Binary Search Test 8 passed" << endl;
		xpassed++;
	}else {
		cout << "-----> Binary Search Test 8 failed" << endl;
	}


	long int setA[] = {12, 22, 37, 21, 18, 77, 45, 12, 93};
	long int setB[] = {77, 45, 45, 19, 31, 43, 85, 22, 91};
	const long int resultSet[] = {22, 77, 45};
	const size_t SET_SIZE = sizeof(setA) / sizeof(setA[0]);
	long int setC[SET_SIZE];

	size_t intersectionSize = Intersection(setA, setB, setC, SET_SIZE);


	if (intersectionSize == 3){
		cout << "-----> Intersection return passed" << endl;
		xpassed++;
		ok = true;
		for (size_t i = 0; i < intersectionSize; i++) {
			if (setC[i] == resultSet[i]){
				cout << "Position " << i << " matched" << endl;
				xmatched++;
			}else{
				cout << "Position " << i << " did not matched" << endl;
				ok = false;
			}
		}
		if (!ok){
			cout << "-----> Intersection elements failed" << endl;
		}else{
			cout << "-----> Intersection elements passed" << endl;
			xpassed++;
		}

	}else{
		cout << "-----> Intersection return failed" << endl;
	}

	cout << "= = = = = = = = = EXTRA CREDIT = = = = = = = = =" << endl;
	cout << "Passed  " << fixed << setprecision(2) << xpassed / TOTAL_XPASSED * 100 << endl;
	cout << "Matched " << fixed << setprecision(2) << xmatched / TOTAL_XMATCHED * 100 << endl;


	return 0;
}
