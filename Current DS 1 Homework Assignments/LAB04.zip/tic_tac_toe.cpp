/*
	This file will serve as a start point for the students.
	Students:
		DO NOT MODIFY THE PARTS THAT ARE EXPLICITY MARKED AS
		*** DO NOT MODIFY ***

*/

#include <iostream>
#include <fstream>
#include <algorithm>



// *** DO NOT MODIFY ***********************************************************
const size_t DIM = 3;

void InitBoard(char[][DIM]);
void PrintBoard(char[][DIM]);
void TakeTurn(char[][DIM], char, size_t, size_t);
void ReadBoard(ifstream&, char[][DIM]);
int BoardValue(char[][DIM]);
void CopyBoard(char[][DIM], char[][DIM]);
bool IsValid(char[][DIM], size_t, size_t);
bool IsTerminal(char[][DIM]);
char DetermineTurn(char[][DIM]);

// This function is defined for you
void CompTakeTurn(char[][DIM], const size_t);
// This function is defined for you
int Minimax(char[][DIM], char, size_t, const size_t);
// *** END DO NOT MODIFY *******************************************************



// YOU SHOULD CODE THE MAIN
int main(int argc, char **argv)
{
	char board[DIM][DIM];

	return 0;
}

// Coded by student:
char DetermineTurn(char b[][DIM]) {

}

// Coded by student:
void InitBoard(char b[][DIM]){

}

// Coded by student:
void ReadBoard(ifstream& fin, char b[][DIM]){

}

// Coded by student:
void PrintBoard(char b[][DIM]){
}

// Coded by student:
bool IsValid(char b[][DIM], size_t row, size_t col){

}

// Coded by student:
void TakeTurn(char b[][DIM], char p, size_t row, size_t col){

}

// Coded by student:
int BoardValue(char b[][DIM]){
	//return 1 if X wins, -1 if O wins, 0 if tie
}

// Coded by student:
void CopyBoard(char d[][DIM], char s[][DIM]){

}

// Coded by student:
bool IsTerminal(char b[][DIM]){

}

// *** DO NOT MODIFY ***********************************************************
void CompTakeTurn(char b[][DIM], const size_t d)
{
	size_t bestMoveRow = 0;
	size_t bestMoveCol = 0;

	int bestMoveScore = 1000;
	int tmpScore;

	char child[DIM][DIM];

	for(size_t i = 0; i < DIM; i++)
	{
		for(size_t j = 0; j < DIM; j++)
		{
			if(IsValid(b, i, j))
			{
				CopyBoard(child, b);
			  TakeTurn(child, 'O', i, j);
				tmpScore = Minimax(child, 'X', 0, d);
				if(tmpScore < bestMoveScore)
				{
					bestMoveRow = i;
					bestMoveCol = j;
					bestMoveScore = tmpScore;
				}
			}
		}
	}
	TakeTurn(b, 'O', bestMoveRow, bestMoveCol);
}

//GIVEN
int Minimax(char b[][DIM], char p, size_t d, const size_t maxDepth)
{
	if(IsTerminal(b) || d >= maxDepth)
		return BoardValue(b);

	int value;
	//human's turn
	if(p == 'X')
	{
		value = -100;

		char child[DIM][DIM];

		for(size_t i = 0; i < DIM; i++)
		{
			for(size_t j = 0; j < DIM; j++)
			{
				CopyBoard(child, b);
				if(IsValid(child, i, j))
				{
					TakeTurn(child, p, i, j);
					value = max(value, Minimax(child, 'O', d++, maxDepth));
				}
			}
		}
		return value;
	}
	else //computer's turn
	{
		value = 100;

		char child[DIM][DIM];

		for(size_t i = 0; i < DIM * DIM; i++)
		{
			for(size_t j = 0; j < DIM; j++)
			{
				CopyBoard(child, b);
				if(IsValid(child, i, j))
				{
					TakeTurn(child, p, i, j);
					value = min(value, Minimax(child, 'X', d++, maxDepth));
				}
			}
		}
		return value;
	}
}
// *** END DO NOT MODIFY *******************************************************
