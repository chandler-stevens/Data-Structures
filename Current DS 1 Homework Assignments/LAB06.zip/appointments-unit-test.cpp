#include "appointment.h"

#include <sstream>
#include <string>
#include <cassert>
#include <iostream>

using std::stringstream;
using std::string;
using std::cout;
using std::endl;

int main(int argc, char* argv[]){
	stringstream buffer1;
	buffer1.str(
			"John	Doe		20190110123000 20190110124500\n"
			"Jenny	Peters	20190115150000 20190115164502\n"
			"Peter	Heller	20180312102103 20180312123001\n"
			"Maggie	Phoenix	20111201010000 20111201100000\n"
			"George	Patton	20150101142525 20150101160001\n"
			"Betty	Pride	20100915060507 20100915070809\n"
	); // 6 Valid Records

	stringstream buffer2;
	buffer2.str(
			"Peter		Parker	20100229110000 20100219120000\n" // Invalid Start Time
			"Jean-Luc	Picard	20120229131500 20120219135959\n" // Starts after it ends
			"Tony		Stark	20111420010000 20111420010000\n" // Invalid Start and End Time
			"Clint		Barton	20190110250000 20190110150000\n" // Invalid Start Time
			"King		TChalla	20190312080061 20190312083060\n" // Invalid Start and End Time
			"Officer	Sun		20190301080011 20190301083059\n" // Everything OK
	); // 6 Records, 5 invalid records, 1 valid record

	stringstream buffer3;
	buffer3.str(
			"John	Doe		20190110123000 20190110124500\n"
			"John	Doe		20190111123000 20190111124500\n"
			"John	Doe		20190112123000 20190112124500\n"
			"Jenny	Peters	20190115150000 20190115164502\n"
			"Peter	Heller	20180312102103 20180312123001\n"
			"Maggie	Phoenix	20111201010000 20111201100000\n"
			"Maggie	Phoenix	20111205010000 20111205110000\n"
			"George	Patton	20150101142525 20150101160001\n"
			"Betty	Pride	20100915060507 20100915070809\n"
			"Jenny	Peters	20190115150000 20190115164502\n"
			"Jenny	Peters	20190125150000 20190125165006\n"
	); // 11 valid records

	// Testing Appointment Database Struct utility Functions
	AppointmentDB appointmentDB;
	Appointment appointment;

	assert(appointmentDB.Size() == 0);

	assert(appointmentDB.LoadAppointmentDB(buffer1) == 6);

	assert(appointmentDB.GetAppointment(0, appointment) == true);
	assert(appointment.GetStartTime() ==  "20190110123000");
	assert(appointment.GetEndTime() == "20190110124500");
	assert(appointment.GetFullName() == "John Doe");
	assert(appointment.GetTimeDifference() / 60 == 15);
	assert(appointment.GetCharge() == 100);

	assert(appointmentDB.GetAppointment(1, appointment) == true);
	assert(appointment.GetStartTime() ==  "20190115150000");
	assert(appointment.GetEndTime() == "20190115164502");
	assert(appointment.GetFullName() == "Jenny Peters");
	assert(appointment.GetTimeDifference() / 60 == 105);
	assert(appointment.GetCharge() == 400);

	assert(appointmentDB.GetAppointment(2, appointment) == true);
	assert(appointment.GetStartTime() ==  "20180312102103");
	assert(appointment.GetEndTime() == "20180312123001");
	assert(appointment.GetFullName() == "Peter Heller");
	assert(appointment.GetTimeDifference() / 60  == 128);
	assert(appointment.GetCharge() == 500);

	assert(appointmentDB.GetAppointment(3, appointment) == true);
	assert(appointment.GetStartTime() ==  "20111201010000");
	assert(appointment.GetEndTime() == "20111201100000");
	assert(appointment.GetFullName() == "Maggie Phoenix");
	assert(appointment.GetTimeDifference() / 60 == 540);
	assert(appointment.GetCharge() == 1800);

	assert(appointmentDB.GetAppointment(4, appointment) == true);
	assert(appointment.GetStartTime() ==  "20150101142525");
	assert(appointment.GetEndTime() == "20150101160001");
	assert(appointment.GetFullName() == "George Patton");
	assert(appointment.GetTimeDifference() / 60 == 94);
	assert(appointment.GetCharge() == 400);

	assert(appointmentDB.GetAppointment(5, appointment) == true);
	assert(appointment.GetStartTime() ==  "20100915060507");
	assert(appointment.GetEndTime() == "20100915070809");
	assert(appointment.GetFullName() == "Betty Pride");
	assert(appointment.GetTimeDifference() / 60 == 63);
	assert(appointment.GetCharge() == 300);

	assert(appointmentDB.GetAppointment(7, appointment) == false);

	assert(appointmentDB.FindAppointmentByNamePrefix("J") == 0);
	assert(appointmentDB.FindAppointmentByNamePrefix("J", 1) == 1);
	assert(appointmentDB.FindAppointmentByNamePrefix("J", 2) == -1);
	assert(appointmentDB.FindAppointmentByNamePrefix("Mag") == 3);
	assert(appointmentDB.FindAppointmentByNamePrefix("Mag", 4) == -1);

	appointmentDB.Clear();
	assert(appointmentDB.LoadAppointmentDB(buffer2) == 1);

	appointmentDB.Clear();
	assert(appointmentDB.LoadAppointmentDB(buffer3) == 10);

	cout << "All tests passed!" << endl;

	return 0;
}
