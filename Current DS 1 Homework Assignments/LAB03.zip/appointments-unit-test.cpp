#include "appointment.h"

#include <sstream>
#include <string>
#include <cassert>
#include <iostream>

using std::stringstream;
using std::string;
using std::cout;
using std::endl;

int main(int argc, char* argv[]){
	stringstream buffer1;
	buffer1.str(
			"John	Doe		20190110123000 20190110124500\n"
			"Jenny	Peters	20190115150000 20190115164502\n"
			"Peter	Heller	20180312102103 20180312123001\n"
			"Maggie	Phoenix	20111201010000 20111201100000\n"
			"George	Patton	20150101142525 20150101160001\n"
			"Betty	Pride	20100915060507 20100915070809\n"
	); // 6 Valid Records

	stringstream buffer2;
	buffer2.str(
			"Peter		Parker	20100229110000 20100219120000\n" // Invalid Start Time
			"Jean-Luc	Picard	20120229131500 20120219135959\n" // Starts after it ends
			"Tony		Stark	20111420010000 20111420010000\n" // Invalid Start and End Time
			"Clint		Barton	20190110250000 20190110150000\n" // Invalid Start Time
			"King		TChalla	20190312080061 20190312083060\n" // Invalid Start and End Time
			"Officer	Sun		20190301080011 20190301083059\n" // Everything OK
	); // 6 Records, 5 invalid records, 1 valid record

	stringstream buffer3;
	buffer3.str(
			"John	Doe		20190110123000 20190110124500\n"
			"John	Doe		20190111123000 20190111124500\n"
			"John	Doe		20190112123000 20190112124500\n"
			"Jenny	Peters	20190115150000 20190115164502\n"
			"Peter	Heller	20180312102103 20180312123001\n"
			"Maggie	Phoenix	20111201010000 20111201100000\n"
			"Maggie	Phoenix	20111205010000 20111205110000\n"
			"George	Patton	20150101142525 20150101160001\n"
			"Betty	Pride	20100915060507 20100915070809\n"
			"Jenny	Peters	20190115150000 20190115164502\n"
			"Jenny	Peters	20190125150000 20190125165006\n"
	); // 11 valid records


	// Testing General Purpose Functions
	assert(IsValidDate("20100102200500") == true);
	assert(IsValidDate("20101302200500") == false); // Month 13
	assert(IsValidDate("20100132200500") == false); // Jan 32
	assert(IsValidDate("20101302240500") == false); // Hour 23
	assert(IsValidDate("20100102206500") == false);  // Minute 65
	assert(IsValidDate("20100102200580") == false);  // Second 80
	assert(IsValidDate("20080229010000") == true);	// Correct Leap year
	assert(IsValidDate("20090229010000") == false);	// Incorrect Leap year

	assert(FormatDateTime("20190110123000") == "Jan 10 12:30:00 2019");
	assert(FormatDateTime("20190115150000") == "Jan 15 15:00:00 2019");
	assert(FormatDateTime("20011103121500") == "Nov  3 12:15:00 2001");
	assert(FormatDateTime("20190301083059") == "Mar  1 08:30:59 2019");

	// Testing Appointment struct utility Functions
	Appointment appointment;

	appointment.start = "20190110123000";
	appointment.end = "20190110124500";
	appointment.firstName = "Bugs";
	appointment.lastName = "Bunny";

	assert(GetStartTime(appointment) ==  "20190110123000");
	assert(GetEndTime(appointment) == "20190110124500");
	assert(GetFullName(appointment) == "Bugs Bunny");
	assert(GetTimeDifference(appointment) == 900);
	assert(GetCharge(appointment) == 100);

	// Testing Appointment Database Struct utility Functions
	AppointmentDB appointmentDB;

	InitAppointmentDB(appointmentDB);
	assert(appointmentDB.count == 0);

	assert(LoadAppointmentDB(appointmentDB, buffer1) == 6);

	assert(GetAppointment(appointmentDB, 0, appointment) == true);
	assert(GetStartTime(appointment) ==  "20190110123000");
	assert(GetEndTime(appointment) == "20190110124500");
	assert(GetFullName(appointment) == "John Doe");
	assert(GetTimeDifference(appointment) / 60 == 15);
	assert(GetCharge(appointment) == 100);

	assert(GetAppointment(appointmentDB, 1, appointment) == true);
	assert(GetStartTime(appointment) ==  "20190115150000");
	assert(GetEndTime(appointment) == "20190115164502");
	assert(GetFullName(appointment) == "Jenny Peters");
	assert(GetTimeDifference(appointment) / 60 == 105);
	assert(GetCharge(appointment) == 400);

	assert(GetAppointment(appointmentDB, 2, appointment) == true);
	assert(GetStartTime(appointment) ==  "20180312102103");
	assert(GetEndTime(appointment) == "20180312123001");
	assert(GetFullName(appointment) == "Peter Heller");
	assert(GetTimeDifference(appointment) / 60  == 128);
	assert(GetCharge(appointment) == 500);

	assert(GetAppointment(appointmentDB, 3, appointment) == true);
	assert(GetStartTime(appointment) ==  "20111201010000");
	assert(GetEndTime(appointment) == "20111201100000");
	assert(GetFullName(appointment) == "Maggie Phoenix");
	assert(GetTimeDifference(appointment) / 60 == 540);
	assert(GetCharge(appointment) == 1800);

	assert(GetAppointment(appointmentDB, 4, appointment) == true);
	assert(GetStartTime(appointment) ==  "20150101142525");
	assert(GetEndTime(appointment) == "20150101160001");
	assert(GetFullName(appointment) == "George Patton");
	assert(GetTimeDifference(appointment) / 60 == 94);
	assert(GetCharge(appointment) == 400);

	assert(GetAppointment(appointmentDB, 5, appointment) == true);
	assert(GetStartTime(appointment) ==  "20100915060507");
	assert(GetEndTime(appointment) == "20100915070809");
	assert(GetFullName(appointment) == "Betty Pride");
	assert(GetTimeDifference(appointment) / 60 == 63);
	assert(GetCharge(appointment) == 300);

	assert(GetAppointment(appointmentDB, 7, appointment) == false);

	assert(FindAppointmentByNamePrefix(appointmentDB, "J") == 0);
	assert(FindAppointmentByNamePrefix(appointmentDB, "J", 1) == 1);
	assert(FindAppointmentByNamePrefix(appointmentDB, "J", 2) == -1);
	assert(FindAppointmentByNamePrefix(appointmentDB, "Mag") == 3);
	assert(FindAppointmentByNamePrefix(appointmentDB, "Mag", 4) == -1);

	InitAppointmentDB(appointmentDB);
	assert(LoadAppointmentDB(appointmentDB, buffer2) == 1);

	InitAppointmentDB(appointmentDB);
	assert(LoadAppointmentDB(appointmentDB, buffer3) == 10);

	return 0;
}
