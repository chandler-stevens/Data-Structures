/* Chandler Stevens
   CSC 2430
   January 30, 2017
   Name Formatter
   Converts a name input in form of last, first
    into form of first last and
    finds the the greater cstring. */

#include <iostream>
using namespace std;

// string package header file
#include "stringPkg.h"

// auxiliary function prototypes
void badInput(void);
void createFirstName(const char[], char[], const int, int);
void createLastName(const char[], char[], const int, int);
void displayNewName(const char[], char[], const char[],
					const char[], const int);

// constant for input buffer size
const int MAX = 250;

/* Purpose: primary function of program used to call auxiliary functions
   Parameters: none
   Returns: program end */
int main(void)
{
	char name[MAX], firstName[MAX], lastName[MAX], newName[MAX];
	cout << "Please enter a name in the form: of Last, First\n";
	cin.getline(name, MAX);
	int comma = stringFindchar(name, ',');
	char next = stringGetchar(name, (comma + 1));
	// check that there is a comma that is followed by whitespace
	if (comma == -1 || (next != ' ' && next != '\t'))
	{
		badInput();
		return (1);
	}
	createFirstName(name, firstName, MAX, comma);
	createLastName(name, lastName, MAX, comma);
	// check that both pieces of the name are not empty
	if (stringLength(firstName) && stringLength(lastName))
	{
		displayNewName(name, newName, firstName, lastName, MAX);
		return (0);
	}
	badInput();
	return (1);
}

/* Purpose: auxiliary function used to end program if bad input is given
   Parameters: None
   Returns: nothing */
void badInput(void)
{
	cout << "You must type only one last name and only one first name.\n"
		 << "You must only use lowercase and uppercase letters.\n"
		 << "You must separate the two names with a single comma followed\n"
		 << " by at least one space and/or at least one tab.\n\n";
}

/* Purpose: auxiliary function used to create the person's first name
   Parameters: constant raw input cstring, last name cstring, maximum buffer
    size integer, and positional index integer
   Returns: nothing*/
void createFirstName(const char name[], char firstName[], const int MAX, int index = 0)
{
	//Find the first alphabetical letter after the comma
	char nextChar = stringGetchar(name, index);
	while ((nextChar < 'A') || ((nextChar > 'Z') && (nextChar < 'a'))
		|| (nextChar > 'z'))
	{
		++index;
		nextChar = stringGetchar(name, index);
	}
	stringSubstring(firstName, MAX, name, index);
	index = 0;
	/* Cut off the first name right before the first
	    character that is not an alphabetical letter */
	nextChar = stringGetchar(firstName, index);
	while (((nextChar >= 'A') && (nextChar <= 'Z')) ||
		((nextChar >= 'a') && (nextChar <= 'z')))
	{
		++index;
		nextChar = stringGetchar(firstName, index);
	}
	firstName[index] = 0;
}

/* Purpose: auxiliary function used to create the person's last name
   Parameters: raw input cstring, last name cstring, maximum buffer
    size integer, and positional index integer
   Returns: nothing */
void createLastName(const char name[], char lastName[], const int MAX, const int comma)
{
	int index = 0;
	// find the first alphabetical letter
	char nextChar = stringGetchar(name, index);
	while ((nextChar != 0) && ((nextChar < 'A') ||
		  ((nextChar > 'Z') && (nextChar < 'a')) || (nextChar > 'z')))
	{
		++index;
		nextChar = stringGetchar(name, index);
	}
	stringSubstring(lastName, MAX, name, index, comma);
	index = 0;
	/* cut off the last name right before the first
	    character that is not an alphabetical letter */
	nextChar = stringGetchar(lastName, index);
	while (((nextChar >= 'A') && (nextChar <= 'Z')) ||
		((nextChar >= 'a') && (nextChar <= 'z')))
	{
		++index;
		nextChar = stringGetchar(lastName, index);
	}
	lastName[index] = 0;
}

/* Purpose: auxiliary function used to create and display
    the person's formatted full name
   Parameters: raw input cstring, formatted name cstring,
    first name cstring, last name cstring, and
    maximum buffer size integer
   Returns: nothing */
void displayNewName(const char name[], char newName[], const char firstName[],
					const char lastName[], const int MAX)
{
	stringCopy(newName, MAX, firstName);
	stringConcatenate(newName, MAX, " ");
	stringConcatenate(newName, MAX, lastName);
	cout << "Thank you " << newName << " for entering " << name
		 << ".\nThe First Name is ";
	int result = stringCompare(firstName, lastName);
	if (result > 0)
	{
		cout << "greater than";
	}
	else if (result < 0)
	{
		cout << "less than";
	}
	else
	{
		cout << "equal to";
	}
	cout << " the Last Name.\n\n";
}