/* Chandler Stevens
   CSC 2430
   January 20, 2017
   Phone Number Formatter
   This program reformats raw phone numbers into standard
    format and checks if the number is an SPU number.*/

#include <iostream>
// include cstring library for C-String functions
#include <cstring>
using namespace std;

// constant values
const int NUMBER = 260, NO_AREA = 7, AREA = 10, NEW_NUMBER = 15, SPU = 9;

// auxiliary function prototypes
void noAreaCode(char number[NUMBER], char newNumber[NEW_NUMBER]);
void withAreaCode(char number[NUMBER], char newNumber[NEW_NUMBER]);
void spuCheck(char newNumber[NEW_NUMBER]);

/* Purpose: Primary function of program used to call auxiliary functions
   Parameters: None
   Returns: Program end*/
int main(void)
{
	char number[NUMBER], newNumber[NEW_NUMBER];
	do
	{
		cout << "Enter an unformatted phone number > ";
		cin.getline(number, NUMBER);
		if (strnlen_s(number, NUMBER) == NO_AREA || strnlen_s(number, NUMBER) == AREA)
		{
			if (strnlen_s(number, NUMBER) == NO_AREA)
			{
				noAreaCode(number, newNumber);
			}
			else
			{
				withAreaCode(number, newNumber);
			}
			cout << "   Unformatted phone number: " << number << "\n"
			 	 << "   Formatted phone number: " << newNumber << "\n";
			spuCheck(newNumber);
			cout << "\n";
		}
		else
		{
			cout << "\nInvalid phone number entered.\n"
				 << "Please enter an unformatted phone number"
				 << " with either 7 or 10 digits.\n\n";
		}
	} while (strnlen_s(number, NUMBER));
	return (0);
}

/* Purpose: Auxiliary function used to format number if area code is missing
   Parameters: C-String of unformatted number and C-String for formatted number
   Returns: Nothing*/
void noAreaCode(char number[NUMBER], char newNumber[NEW_NUMBER])
{
	strncpy_s(newNumber, NEW_NUMBER, "(206) ", 6);
	strncat_s(newNumber, NEW_NUMBER, number, 3);
	strncat_s(newNumber, NEW_NUMBER, "-", 1);
	strncat_s(newNumber, NEW_NUMBER, number + 3, 4);
}

/* Purpose: Auxiliary function used to format number if area code exists
   Parameters: C-String of unformatted number and C-String for formatted number
   Returns: Nothing*/
void withAreaCode(char number[NUMBER], char newNumber[NEW_NUMBER])
{
	strncpy_s(newNumber, NEW_NUMBER, "(", 1);
	strncat_s(newNumber, NEW_NUMBER, number, 3);
	strncat_s(newNumber, NEW_NUMBER, ") ", 2);
	strncat_s(newNumber, NEW_NUMBER, number + 3, 3);
	strncat_s(newNumber, NEW_NUMBER, "-", 1);
	strncat_s(newNumber, NEW_NUMBER, number + 6, 4);
}

/* Purpose: Auxiliary function used to check if the number is an SPU number
   Parameters: C-String for formatted number
   Returns: Nothing*/
void spuCheck(char newNumber[NEW_NUMBER])
{
	if (!(strncmp(newNumber, "(206) 281", SPU)) || !(strncmp(newNumber, "(206) 286", SPU)))
	{
		cout << "   This is an SPU phone number.\n";
	}
}