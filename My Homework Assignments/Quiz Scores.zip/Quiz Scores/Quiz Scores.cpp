/* Chandler Stevens
   CSC 2430
   11 January 2017
   Quiz Score Frequency Analyzer
   This program processes student quiz scores to display the highest score,
    the lowest score, and the most frequent score.*/

#include <iostream>
// needed for setw(n) function
#include <iomanip>
using namespace std;

// constant for array size
const int MAX = 51;

// auxiliary function prototypes
int findHighScore(int scores[]);
int findLowScore(int scores[]);
int findHighFrequency(int scores[]);
void inputData(int scores[]);
void scoreChart(int scores[]);
void frequencyChart(int scores[]);

/* Purpose: Primary function of program used to call auxiliary functions
   Parameters: None
   Returns: Program end*/
int main(void)
{
	int scores[MAX] = { 0 };
	cout << "Welcome to the Quiz Score Frequency Analyzer, by Chandler Stevens\n"
		<< "\nEnter a list of pairs of values: \"QuizScoreValue  ScoreCount\".\n"
		<< "  Example:  35  5     indicates 5 more students received a score of 35"
		<< "\nEnter  \"- 1  0\" when finished:\n";
	int grade = 0, frequency = 0;
	// send user input into the array
	do
	{
		cin >> grade;
		if (grade >= 0 && grade <= (MAX - 1))
		{
			cin >> frequency;
			scores[grade] += frequency;
		}
		else if (grade > (MAX - 1))
		{
			return 0;
		}
	}
	while (grade >= 0);
	// process data using auxiliary functions
	inputData(scores);
	scoreChart(scores);
	frequencyChart(scores);
	cout << "\n\n";
	return 0;
}

/* Purpose: Auxiliary function of program used to calculate the highest score
   Parameters: Array of integers representing quantity of each quiz score
   Returns: Highest achieved quiz score*/
int findHighScore(int scores[])
{
	int highScore = 0;
	for (int i = 0; i < MAX; ++i)
	{
		if (scores[i] != 0)
		{
			highScore = i;
		}
	}
	return highScore;
}

/* Purpose: Auxiliary function of program used to calculate the lowest score
   Parameters: Array of integers representing quantity of each quiz score
   Returns: Lowest achieved quiz score*/
int findLowScore(int scores[])
{
	int lowScore = 0;
	for (int i = (MAX - 1); i >= 0; --i)
	{
		if (scores[i] != 0)
		{
			lowScore = i;
		}
	}
	return lowScore;
}

/* Purpose: Auxiliary function of program used to calculate the highest frequency
   Parameters: Array of integers representing quantity of each quiz score
   Returns: Most frequent score*/
int findHighFrequency(int scores[])
{
	int highFrequency = 0;
	for (int i = 0; i < MAX; ++i)
	{
		if (scores[i] > highFrequency)
		{
			highFrequency = scores[i];
		}
	}
	return highFrequency;
}

/* Purpose: Auxiliary function of program used to display the input data
   Parameters: Array of integers representing quantity of each quiz score
   Returns: Nothing*/
void inputData(int scores[])
{
	int highScore = findHighScore(scores);
	int lowScore = findLowScore(scores);
	cout << "\n---Input Data---\nScore: Frequency\n\n";
	for (int i = lowScore; i <= highScore; ++i)
	{
		cout << setw(5) << i << ":" << setw(6) << scores[i] << "\n";
	}
	cout << "\nThe smallest score value is " << lowScore
		<< "\nThe largest score value is " << highScore
		<< "\nThe largest frequency count is " << findHighFrequency(scores);
}

/* Purpose: Auxiliary function of program used to display the Score Chart
   Parameters: Array of integers representing quantity of each quiz score
   Returns: Nothing*/
void scoreChart(int scores[])
{
	cout << "\n\nScore: Frequency Vertical Bar Chart\n\n";
	for (int i = findLowScore(scores); i <= findHighScore(scores); ++i)
	{
		cout << setw(5) << i << ": ";
		for (int j = 0; j < scores[i]; ++j)
		{
			cout << "*";
		}
		cout << "\n";
	}
}

/* Purpose: Auxiliary function of program used to display the Frequency Chart
   Parameters: Array of integers representing quantity of each quiz score
   Returns: Nothing*/
void frequencyChart(int scores[])
{
	int highScore = findHighScore(scores);
	int lowScore = findLowScore(scores);
	cout << "\nFrequency: Score Horizontal Bar Chart\n\n";
	for (int i = findHighFrequency(scores); i > 0; --i)
	{
		cout << "    ^" << setw(4) << i << ": ";
		for (int j = lowScore; j <= highScore; ++j)
		{
			if (scores[j] >= i)
			{
				cout << "  *";
			}
			else
			{
				cout << "   ";
			}
		}
		cout << "\n";
	}
	cout << "---------: ";
	for (int i = lowScore; i <= highScore; ++i)
	{
		cout << "--^";
	}
	cout << "\n    Score: ";
	for (int i = lowScore; i <= highScore; ++i)
	{
		cout << setw(3) << i;
	}
}