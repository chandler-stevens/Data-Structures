/* *******************************************************
   Implementation file LabListP.cpp for the ADT list.
   Pointer-based implementation.
   ******************************************************* */

// header file
#include "LabListP.h"
// for NULL
#include <cstddef>
// for assert()
#include <cassert>

// Default Constructor
ListClass::ListClass()
: size(0), head(NULL){}

// Destructor
ListClass::~ListClass()
{
	// repeatedly delete item 1
	while (size != 0)
	{
		remove (1);
	}
}

bool ListClass::isEmpty() const
{
	return bool(size == 0);
}

int ListClass::getLength() const
{
	return size;
}

// Copy Constructor: Make DEEP copy
ListClass::ListClass(const ListClass& existingList)
	: size(existingList.size)
{
	if (existingList.head == NULL)
	{
		// original list is empty
		head = NULL;
	}
	else
	{
		// copy first node
		head = new ListNode;
		// check allocation
		assert(head != NULL);
		head->item = existingList.head->item;
		// copy rest of list
		// new list pointer
		ListNode *newPtr = head;
		// newPtr points to last node in new list
		// origPtr points to nodes in original list
		for (ListNode *origPtr = existingList.head->next;
			           origPtr != NULL;
			           origPtr = origPtr->next)
		{
			// link new node to end of list
			newPtr->next = new ListNode;
			assert(newPtr->next != NULL);
			newPtr = newPtr->next;
			// copy the data
			newPtr->item = origPtr->item;
			newPtr->next = NULL;
		}
	}
}

// Assignment operator: Make DEEP copy
ListClass& ListClass::operator=(const ListClass& rhs)
{
	if (this != &rhs)
	{
		// repeatedly delete item 1
		while (size != 0)
		{
			remove(1);
		}
		size = rhs.size;
		if (rhs.head == NULL)
		{
			// original list is empty
			head = NULL;
		}
		else
		{
			// copy first node
			head = new ListNode;
			// check allocation
			assert(head != NULL);
			head->item = rhs.head->item;
			// copy rest of list
			// new list pointer
			ListNode *newPtr = head;
			// newPtr points to last node in new list
			// origPtr points to nodes in original list
			for (ListNode *origPtr = rhs.head->next;
				origPtr != NULL;
				origPtr = origPtr->next)
			{
				// link new node to end of list
				newPtr->next = new ListNode;
				assert(newPtr->next != NULL);
				newPtr = newPtr->next;
				// copy the data
				newPtr->item = origPtr->item;
				newPtr->next = NULL;
			}
		}
	}
	return(*this);
}

/* ----------------------------------------------------------------------
   Locates a specified node in a linked list.
   Precondition: position is the number of the desired node.
   Postcondition: Returns a pointer to the desired node.
   If position < 1 or position > size (the number of nodes in the list),
    returns NULL.
   ---------------------------------------------------------------------- */
ListClass::ListNode *ListClass::ptrTo(int position) const
{
	if ((position < 1) || (position > size))
	{
		return NULL;
	}
	else
	{
		// count from the beginning of the list
		ListNode *cur = head;
		for (int skip = 1; skip < position; ++skip)
		{
			cur = cur->next;
		}
		return cur;
	}
}

bool ListClass::insert(int position, ListItemType& newItem)
{
	int newLength = size + 1;
	// check parameter validity
	bool success = bool( (position >= 1) && (position <= newLength) );
	if (success)
	{
		// create new node and place newItem in it
		ListNode *newPtr = new ListNode;
		if (newPtr == NULL)
		{
			// cannot insert - allocation failed
			return (false);
		}
		size = newLength;
		newPtr->item = newItem;
		// attach new node to list
		if (position == 1)
		{
			// insert new node at beginning of list
			newPtr->next = head;
			head = newPtr;
		}
		else
		{
 			// insert new node to right of previous node
 			ListNode *prev = ptrTo(position - 1);
			// insert new node to right of prev
			newPtr->next = prev->next;
			prev->next = newPtr;
		}
	}
	return (success);
}

bool ListClass::remove(int position)
{
	bool success = bool( (position >= 1) && (position <= size) );
	if (success)
	{
		ListNode *cur;
		--size;
		if (position == 1)
		{
			// delete the first node from the list
			// save pointer to node
			cur = head;
			head = head->next;
		}
		else
		{
			ListNode *prev = ptrTo(position - 1);
			// delete the node after the node to which prev points
			// save pointer to node
			cur = prev->next;
			prev->next = cur->next;
		}
		// return node to system
		// safety - remove node from list
		cur->next = NULL;
		delete cur;
		// safety
		cur = NULL;
	}
	return(success);
}

bool ListClass::retrieve(int position, ListItemType& dataItem) const
{
	bool success = bool((position >= 1) && (position <= size));
	if (success)
	{
		// get pointer to node, then data in node
		ListNode *cur = ptrTo(position);
		dataItem = cur->item;
	}
	return(success);
}