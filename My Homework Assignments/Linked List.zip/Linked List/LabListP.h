/* *********************************************************
   Header file LabListP.h for the ADT list.
   Pointer-based implementation.
   The first "position" in a list is position = 1,
    as implemented in the insert(), remove(), retrieve(),
    and private ptrTo() methods.
   ********************************************************* */
#ifndef LABLISTP_H
#define LABLISTP_H

/* *********************************************************
   The "typedef" below must be configured for the type
    of data stored in each node in the list
   *********************************************************
   typedef desired - type of list - item ListItemType; */
typedef int ListItemType;

class ListClass
{
public:
	// constructors and destructor:
	// default constructor
	ListClass();
	// destructor
	~ListClass();
	// copy constructor
	ListClass(const ListClass& existingList);
	// assignment operator
	ListClass& operator=(const ListClass& rhs);
	// list operations:
	bool isEmpty() const;
	int  getLength() const;
	// methods return true if successful, false otherwise
	bool insert(int position, ListItemType& newItem);
	bool remove(int position);
	bool retrieve(int position, ListItemType& dataItem) const;
private:
	struct ListNode
	{
		ListItemType  item;
		ListNode     *next;
	};
	// number of items in list
	int       size;
	// pointer to linked list of items
	ListNode *head;
	ListNode *ptrTo(int position) const;
	// returns a pointer to the node at position (1 .. k) in list
};

// !LABLISTP_H
#endif