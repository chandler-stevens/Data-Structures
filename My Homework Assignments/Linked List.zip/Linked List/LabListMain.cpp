/* Chandler Stevens
   CSC 2430
   March 8, 2017
   LabListRandom
   Generates one unsorted and two sorted linked lists of random numbers */

#include <iostream>
#include <iomanip>
#include <cstddef>
#include <limits>
using namespace std;

#include "LabListP.h"
#include "SortedLabList.h"

void printListClass(char [], const ListClass&);
void printSortedListClass(char [], const SortedListClass&);
void compareLists(char [], const ListClass&, char [], const SortedListClass&);

/* Purpose: Primary function of program used to call auxiliary functions
   Parameters: None
   Returns: Program end */
int main(void)
{
	/* /////////////////////////////////////////////////
	   setup */
	// number of items, used only to create initial list of values
	const int N = 10;
	// value range. Set to SHRT_MAX for a list of values from 0 .. 32767
	const int RANGE = 32768;
	/* prepare random number generator with initial seed value
	    and discard the first few data items in the sequence */
	srand(3);
	for (int i = 0; i < 10; ++i)
		rand();
	/* /////////////////////////////////////////////////
	   greeting */
	cout << "Linked List Lab: Implemented by Chandler Stevens" << endl;
	cout << "Randomly generate list of " << N << " values in range 0-"
		 << RANGE - 1 << "\n and convert into a sorted list" << endl << endl;
	/* /////////////////////////////////////////////////
	    create initial "by position" data value list */
	ListClass listByPosition;
	for (int i = 1; i <= N; ++i)
	{
		// produce next random number value
		int val = rand() % RANGE;
		// put val into list at position i
		listByPosition.insert(i, val);
	}
	// output initial data list
	printListClass("listByPosition", listByPosition);
	SortedListClass firstSortedList;
	for (int i = 1; i <= N; ++i)
	{
		// produce next random number value
		int val;
		if (listByPosition.retrieve(i, val))
		{
			// put val into list at position i
			firstSortedList.insert(val);
		}
	}
	printSortedListClass("firstSortedList", firstSortedList);
	compareLists("listByPosition", listByPosition, 
		         "firstSortedList", firstSortedList);
	SortedListClass secondSortedList;
	secondSortedList = firstSortedList;
	for (int i = 0; i < 2; i++)
	{
		firstSortedList.remove(1);
	}
	int value = -10;
	secondSortedList.insert(value);
	cout << "Modified original sortedlist after removing the first two items:\n";
	printSortedListClass("firstSortedList", firstSortedList);
	cout << "Modified sortedlistcopy after inserting the value ("
		 << value << "):\n";
	printSortedListClass("secondSortedList", secondSortedList);
	return (0);
}

/* Purpose: Auxiliary function used to print a linked list
   Parameters: (Cstring) name and (Constant reference ListClass) linked list
   Returns: Nothing */
void printListClass(char listName[], const ListClass& list)
{
	int numitems = list.getLength();
	cout << listName << ": length=" << numitems << " items" << endl;
	for (int i = 1; i <= numitems; ++i)
	{
		int val;
		if (list.retrieve(i, val))
		{
			cout << setw(3) << i << ": " << setw(5) << val << endl;
		}
		else
		{
			cout << "Cannot retrieve item from position " << i << endl;
		}
	}
	cout << endl;
}

/* Purpose: Auxiliary function used to print a sorted linked list
   Parameters: (Cstring) name and
    (Constant reference SortedListCLass) sorted linked list
   Returns: Nothing */
void printSortedListClass(char sortedListName[],
						  const SortedListClass& sortedList)
{
	int numitems = sortedList.getLength();
	cout << sortedListName << ": length=" << numitems << " items" << endl;
	for (int i = 1; i <= numitems; ++i)
	{
		int val;
		if (sortedList.retrieve(i, val))
		{
			cout << setw(3) << i << ": " << setw(5) << val << endl;
		}
		else
		{
			cout << "Cannot retrieve item from position " << i << endl;
		}
	}
	cout << endl;
}

/* Purpose: Auxiliary function used to compare two linked lists
   Parameters: Two cstring name values,
    constant linked list reference, and constant sorted linked list reference
   Returns: Nothing */
void compareLists(char listName[], const ListClass& list,
	              char sortedListName[], const SortedListClass& sortedList)
{
	int numItems = list.getLength(), val;
	cout << "Correlation between locations of items in listbyposition and sortedlist\n";
	for (int i = 1; i <= numItems; ++i)
	{
		if (list.retrieve(i, val))
		{
			cout << listName << "[" << setw(3) << i << "] = " << setw(5) << val
				 << " --> " << sortedListName << "[" << setw(3)
				 << sortedList.find(val) << "]\n";
		}
		else
		{
			cout << "Cannot retrieve item from position " << i << "\n";
		}
	}
	cout << "\n";
}