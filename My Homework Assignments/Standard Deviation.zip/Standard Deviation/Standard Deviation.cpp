/*Chandler Stevens
CSC 2430
January 4, 2017
Population Standard Deviation Calculator
This program calculates the mean of a set of given numbers and outputs
 the mean and the population standard deviation of the given numbers.*/

#include <iostream>
//Optional libraries include array and cmath
using namespace std;

//Constant quantity of elements that will be in the array
int const QUANTITY = 10;

//Auxilary function prototypes
float calculateMean(float parameter[], int);
float calculateStandardDeviation(float parameter[], int);

/*Purpose: Primary function of program used to call auxiliary functions
Parameters: None
Returns: Program end*/
int main(void)
{
	//Declare the array and assign the constant value
	// as the array's quantity of elements
	float valueArray[QUANTITY];

	//Prompt user for required quantity of numerical values
	cout << "Please enter " << QUANTITY << " numbers that are each separated\n"
		<< "by whitespace and then press the Enter key:\n";

	//Assign each number from the user's input to the array
	for (int i = 0; i < QUANTITY; ++i)
	{
		//Read each number into the input stream by stopping at each whitespace
		cin >> valueArray[i];
	}

	float min = valueArray[0], max = valueArray[0];

	for (int i = 0; i < QUANTITY; ++i)
	{
		if (valueArray[i] < min)
		{
			min = valueArray[i];
		}
	}

	cout << fixed << "\nThe smallest value is " << min << "\n";

	for (int i = 0; i < QUANTITY; ++i)
	{
		if (valueArray[i] > max)
		{
			max = valueArray[i];
		}
	}

	cout << "\nThe largest value is " << max << "\n";

	/*Assign the returned numerical value from the call
	 of the mean calculation function to the mean*/
	float mean = calculateMean(valueArray, QUANTITY);

	/*Assign the returned numerical value from the call of the population standard
	 deviation calculation function to the population standard deviation*/
	float standardDeviation = calculateStandardDeviation(valueArray, QUANTITY);

	//Output the mean and population standard deviation
	cout << "\nThe mean or average of the numbers is:\n" << mean
		<< "\n\nThe population standard deviation of the numbers is:\n"
		<< standardDeviation << "\n\n";
	return 0;
}

/*Purpose: Auxiliary function used to calculate
 the mean of all the numbers in an array
Parameters: One array with a specified quantity of floating-point values and
 one integer that specifies the quantity of values within the array
Returns: Floating-point value of the mean of all the numbers in the array*/
float calculateMean(float valueArray[], int quantity)
{
	//Declare and initialize the sum of all the numbers in the array
	float sum = 0;

	//Add each number in the array to the sum
	for (int i = 0; i < quantity; ++i)
	{
		sum += valueArray[i];
	}

	/*Calculate the mean of all the numbers in the array by
	 dividing the sum of all the numbers by the quantity of numbers*/
	float mean = sum / quantity;

	//Return the mean of all the numbers in the array
	return mean;
}

/*Purpose: Auxiliary function used to calculate
 the population standard deviation of all the numbers in an array
Parameters: One array with a specified quantity of floating-point values and
 one integer that specifies the quantity of values within the array
Returns: Floating-point value of the population standard deviation
 of all the numbers in the array*/
float calculateStandardDeviation(float valueArray[], int quantity)
{
	/*Assign the returned numerical value from the call
	 of the mean calculation function to the mean*/
	float mean = calculateMean(valueArray, quantity), varianceSum = 0;

	//Calculate the numerator of the variance of all the numbers in the array
	for (int i = 0; i < quantity; ++i)
	{
		varianceSum += pow((valueArray[i] - mean), 2);
	}

	/*Calculate the population standard deviation of all the numbers in the
	 array by calcualting the square root of the variance of the numbers*/
	float standardDeviation = sqrt(varianceSum/quantity);

	//Return the population standard deviation of all the numbers in the array
	return standardDeviation;
}