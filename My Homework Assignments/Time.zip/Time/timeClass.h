//////////////////////////////////////////////////////////////////
// timeClass.h
// Type for representing time.

#ifndef _TIME_CLASS_H
#define _TIME_CLASS_H

#include <string>

class Time {
public:
	// Set of operations
	// Default constructor
	Time(void);
	// Convert constructor
	Time(const int, const int, const int);
	// Retrieve seconds
	int getSeconds(void) const;
	// Retrieve minutes
	int getMinutes(void) const;
	// Retrieve hours
	int getHours(void) const;
	// Modify seconds
	void setSeconds(const int);
	// Modify minutes
	void setMinutes(const int);
	// Modify hours
	void setHours(const int);
	// Increase seconds
	void incrementSeconds(const int);
	// Increase minutes
	void incrementMinutes(const int);
	// Increase hours
	void incrementHours(const int);
	// Display in 24-hour clock
	string get24HourFormat(void) const;
	// Display in 12-hour clock
	string get12HourAmPmFormat(void) const;
private:
	// Set of values
	// Hours, minutes, and seconds
	int m_h, m_m, m_s;
};

#endif