// Written by: Chandler Stevens
// Main test program

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <ctime>
using namespace std;

// import time header
#include "timeClass.h"

// prototype to output string representation
void testoutputformats(Time& t);

/* Purpose: Primary test function and used to call auxiliary functions
   Parameters: None
   Returns: Program end */
int main(void)
{
	cout << "CSC2430 Time Lab: Written by Chandler Stevens\n\n";
	// create a time variable
	Time alarmTime(22, 50, 30); // 10:50:30 PM
	string alarmString;
	alarmString = alarmTime.get24HourFormat();
	cout << alarmString << "\n"; // 22:50:30
	alarmString = alarmTime.get12HourAmPmFormat();
	cout << alarmString << "\n\n"; // 10:50:30 PM
	alarmTime.incrementSeconds(45); // 10:51:15 PM
	testoutputformats(alarmTime);
	alarmTime.incrementSeconds(200);
	testoutputformats(alarmTime); // 10:54:35 PM
	alarmTime.incrementMinutes(63);
	testoutputformats(alarmTime); // 11:57:35 PM
	alarmTime.incrementHours(24);
	testoutputformats(alarmTime); // 11:57:35 PM
	alarmTime.incrementHours(49);
	testoutputformats(alarmTime); // 12:57:35 AM
	alarmTime = Time(6, 30, 0);
	testoutputformats(alarmTime); // reset to 6:30:00 AM
	alarmTime = Time(18, 30, 0);
	testoutputformats(alarmTime); // reset to 6:30:00 PM
	alarmTime = Time();
	testoutputformats(alarmTime); // reset to current time
	alarmTime = Time(-12, -30, -9);
	testoutputformats(alarmTime); // force to current time
	alarmTime = Time(-12, -30, 9);
	testoutputformats(alarmTime); // force to current time
	alarmTime = Time(-12, 30, 9);
	testoutputformats(alarmTime); // force to current time
	alarmTime = Time(12, 30, 79);
	testoutputformats(alarmTime); // reset to 12:31:19 PM
	alarmTime = Time(12, 80, 9);
	testoutputformats(alarmTime); // reset to 1:20:09 PM
	alarmTime = Time(12, 70, 79);
	testoutputformats(alarmTime); // reset to 1:11:19 PM
	alarmTime = Time(12, 30, 3619);
	testoutputformats(alarmTime); // reset to 1:30:19 PM
	alarmTime = Time(12, 30, 7279);
	testoutputformats(alarmTime); // reset to 2:31:19 PM
	alarmTime = Time(25, 30, 9);
	testoutputformats(alarmTime); // 1:30:09 AM
	cout << alarmTime.getSeconds() << " Seconds " // 9 Seconds
		 << alarmTime.getMinutes() << " Minutes " // 30 Minutes
		 << alarmTime.getHours() << " Hour\n\n"; // 1 Hour
	alarmTime.setMinutes(179);
	testoutputformats(alarmTime); // 3:59:09 AM
	alarmTime.setSeconds(7260);
	testoutputformats(alarmTime); // 6:00:00 AM
	alarmTime.setHours(20);
	testoutputformats(alarmTime); // 8:00:00 PM
	return(0);
}

/* Purpose: Auxiliary function used to output 24-hour and 12-hour string
    representations of the Time t value
   Parameters: Time reference
   Returns: Nothing */
void testoutputformats(Time& t)
{
	string tmpString;
	tmpString = t.get24HourFormat();
	cout << tmpString << "\n";
	tmpString = t.get12HourAmPmFormat();
	cout << tmpString << "\n\n";
}