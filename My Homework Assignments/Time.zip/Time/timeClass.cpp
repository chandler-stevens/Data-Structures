//////////////////////////////////////////////////////////////////
// timeClass.cpp Implementation File

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <iomanip>
#include <string>
#include <sstream>
#include <ctime>
using namespace std;

// import time header
#include "timeClass.h"

/* Purpose: Default constructor
   Parameters: None */
Time::Time(void)
{
	// get current time in local timezone as hour, min, sec
	time_t now;
	struct tm tstruct;
	// obtain current time on computer, GMT
	time(&now);
	// convert now into local timezone struct
	tstruct = *localtime(&now);
	m_h = tstruct.tm_hour;
	m_m = tstruct.tm_min;
	m_s = tstruct.tm_sec;
}

/* Purpose: Convert constructor
   Parameters: (Constant integers) hours, minutes, and seconds */
Time::Time(const int hour, const int min, const int sec)
{
	if (hour >= 0 && min >= 0 && sec >= 0)
	{
		m_h = hour + (sec / 3600);
		m_s = sec % 3600;
		m_m = min + (m_s / 60);
		m_s %= 60;
		m_h += m_m / 60;
		m_m %= 60;
		m_h %= 24;
	}
	else
	{
		cout << "Invalid time entered. Forcing time to current time.\n";
		// default
		time_t now;
		struct tm tstruct;
		time(&now);
		tstruct = *localtime(&now);
		m_h = tstruct.tm_hour;
		m_m = tstruct.tm_min;
		m_s = tstruct.tm_sec;
	}
}

/* Purpose: Constant method to retrieve seconds
   Parameters: None
   Returns: (Integer) seconds */
int Time::getSeconds(void) const
{
	return (m_s);
}

/* Purpose: Constant method to retrieve minutes
   Parameters: None
   Returns: (Integer) minutes */
int Time::getMinutes(void) const
{
	return (m_m);
}

/* Purpose: Constant method to retrieve hours
   Parameters: None
   Returns: (Integer) hours */
int Time::getHours(void) const
{
	return (m_h);
}

/* Purpose: Method to modify seconds
   Parameters: (Constant integer) seconds
   Returns: Nothing */
void Time::setSeconds(const int sec)
{
	if (sec >= 0)
	{
		m_h += sec / 3600;
		m_s = sec % 3600;
		m_m += m_s / 60;
		m_s %= 60;
		m_h += m_m / 60;
		m_m %= 60;
		m_h %= 24;
	}
	else
	{
		cout << "Invalid seconds entered.\n";
	}
}

/* Purpose: Method to modify minutes
   Parameters: (Constant integer) minutes
   Returns: Nothing */
void Time::setMinutes(const int min)
{
	if (min >= 0)
	{
		m_h += min / 60;
		m_m = min % 60;
		m_h %= 24;
	}
	else
	{
		cout << "Invalid minutes entered.\n";
	}
}

/* Purpose: Method to modify hours
   Parameters: (Constant integer) hours
   Returns: Nothing */
void Time::setHours(const int hour)
{
	if (hour >= 0)
	{
		m_h = hour % 24;
	}
	else
	{
		cout << "Invalid hours entered.\n";
	}
}

/* Purpose: Method to increase seconds
   Parameters: (Constant integer) seconds
   Returns: Nothing */
void Time::incrementSeconds(const int sec)
{
	if (sec >= 0)
	{
		m_s += sec;
		m_h += m_s / 3600;
		m_s %= 3600;
		m_m += m_s / 60;
		m_s %= 60;
		m_h += m_m / 60;
		m_m %= 60;
		m_h %= 24;
	}
	else
	{
		cout << "Invalid seconds entered.\n";
	}
}

/* Purpose: Method to increase minutes
   Parameters: (Constant integer) minutes
   Returns: Nothing */
void Time::incrementMinutes(const int min)
{
	if (min >= 0)
	{
		m_m += min;
		m_h += m_m / 60;
		m_m %= 60;
		m_h %= 24;
	}
	else
	{
		cout << "Invalid minutes entered.\n";
	}
}

/* Purpose: Method to increase hours
   Parameters: (Constant integer) hours
   Returns: Nothing */
void Time::incrementHours(const int hour)
{
	if (hour >= 0)
	{
		m_h += hour;
		m_h %= 24;
	}
	else
	{
		cout << "Invalid hours entered.\n";
	}
}

/* Purpose: Contant method to format time to 24-hour clock
   Parameters: None
   Returns: (String) 24-hour time */
string Time::get24HourFormat(void) const
{
	// create variable to write to
	ostringstream oss;
	// output formatted data to the ostringstream variable (instead of cout)
	oss << setfill('0') << setw(2) << m_h << ":"
		<< setw(2) << m_m << ":" << setw(2) << m_s;
	// convert the ostringstream value into a standard string
	string result = oss.str();
	return result;
}

/* Purpose: Constant method to format time to 12-hour clock
   Parameters: None
   Returns: (String) 12-hour time */
string Time::get12HourAmPmFormat(void) const
{
	// create string stream variable
	ostringstream oss;
	int hour = m_h;
	bool am = true;
	if (hour > 11)
	{
		am = false;
		hour -= 12;
	}
	if (hour == 0)
	{
		hour = 12;
	}
	// output formatted data to the ostringstream variable (instead of cout)
	oss << hour << ":" << setfill('0') << setw(2) << m_m << ":"
		<< setw(2) << m_s << " ";
	if (am)
	{
		oss << "A";
	}
	else
	{
		oss << "P";
	}
	oss << "M";
	// convert the ostringstream value into a standard string
	string result = oss.str();
	return result;
}