//////////////////////////////////////////////////////////////////
// triangle.cpp  Implementation file

#include <iostream>
#include <cmath>
using namespace std;

// import triangle header
#include "triangle.h"

/* Purpose: default constructor
   Parameters: N/A
   Returns: N/A */
Triangle::Triangle(void)
{
	m_a = 3.0;
	m_b = 4.0;
	m_c = 5.0;
}

/* Purpose: convert constructor
   Parameters: 3 constant doubles
   Returns: N/A */
Triangle::Triangle(const double sideA,
		           const double sideB,
		           const double sideC)
{
	// confirm that sides make a triangle
	if (sideA + sideB > sideC &&
		sideA + sideC > sideB &&
		sideB + sideC > sideA &&
		sideA > 0 && sideB > 0 && sideC > 0)
	{
		m_a = sideA;
		m_b = sideB;
		m_c = sideC;
	}
	else
	{
		// convert to default triangle
		cout << "Triangle constructor(" << sideA << ", " << sideB << ", "
			 << sideC << ") - illegal side combination. Forcing default\n";
		m_a = 3.0;
		m_b = 4.0;
		m_c = 5.0;
	}
}

/* Purpose: constant method that retrieves side a
   Parameters: none
   Returns: (double) side a */
double Triangle::getSideA(void) const
{
	return (m_a);
}

/* Purpose: constant method that retrieves side b
   Parameters: none
   Returns: (double) side b */
double Triangle::getSideB(void) const
{
	return (m_b);
}

/* Purpose: constant method that retrieve side c
   Parameters: none
   Returns: (double) side c */
double Triangle::getSideC(void) const
{
	return (m_c);
}

/* Purpose: calculates the area of triangle using Herod's Method
   Parameters: none
   Returns: (double) triangle area */
double Triangle::triangleArea(void) const
{
	double semiperimeter = (m_a + m_b + m_c) / 2,
	area = sqrt((semiperimeter) * (semiperimeter - m_a) *
		        (semiperimeter - m_b) * (semiperimeter - m_c));
	return (area);
}

/* Purpose: check if triangle is pythagorean
   Parameters: none
   Returns: (boolean) result */
bool Triangle::isRightTriangle(void) const
{
	double hypotenuse = 0, result = 0;
	if (m_c > m_a && m_c > m_b)
	{
		hypotenuse = m_c;
		result = sqrt(pow(m_a, 2) + pow(m_b, 2));
	}
	else if (m_a > m_b && m_a > m_c)
	{
		hypotenuse = m_a;
		result = sqrt(pow(m_b, 2) + pow(m_c, 2));
	}
	else
	{
		hypotenuse = m_b;
		result = sqrt(pow(m_a, 2) + pow(m_c, 2));
	}
	if (result == hypotenuse)
	{
		return (true);
	}
	else
	{
		return (false);
	}
}

/* Purpose: check if triangle is equilateral
   Parameters: none
   Returns: (boolean) result */
bool Triangle::isEquilateralTriangle(void) const
{
	if (m_a == m_b && m_b == m_c)
	{
		return (true);
	}
	else
	{
		return (false);
	}
}

/* Purpose: check if triangle is isosceles
   Parameters: none
   Returns: (boolean) result */
bool Triangle::isIsoscelesTriangle(void) const
{
	if ((m_a == m_b && m_a != m_c) ||
		(m_a == m_c && m_a != m_b) ||
		(m_b == m_c && m_b != m_a))
	{
		return (true);
	}
	else
	{
		return (false);
	}
}