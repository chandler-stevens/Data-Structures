// Written by: Chandler Stevens
// Main test program

#include <iostream>
#include <string>
using namespace std;

// import triangle package
#include "triangle.h"

// function prototype
void printTriangleDetails(string, const Triangle&);

/* Purpose: primary test function and used to call auxiliary functions
   Parameters: none
   Returns: program end */
int main(void)
{
	cout << "CSC2430 Triangle Lab: Written by Chandler Stevens\n";
	// default triangle
	Triangle t1;
	printTriangleDetails("Default", t1);
	// convert constructor
	Triangle t2(5, 4, 3);
	printTriangleDetails("t2(5, 4, 3)", t2);
	Triangle t3(4, 5, 3);
	printTriangleDetails("t3(4, 5, 3)", t3);
	Triangle t4(4, 6, 4);
	printTriangleDetails("t4(4, 6, 4)", t4);
	Triangle t5(2, 4, 2);
	printTriangleDetails("t5(2, 4, 2)", t5);
	// assignment of triangle objects
	t5 = t4;
	printTriangleDetails("Assigned t5=t4", t5);
	// create a Triangle object "on the fly"
	t5 = Triangle(3, 3, 3); 
	printTriangleDetails("On-The-Fly assigned Triangle(3, 3, 3)", t5);
	// change 2nd side of t5
	t5 = Triangle(t5.getSideA(), 4, t5.getSideC());
	printTriangleDetails("Changed sideB", t5);
	// change 1st side of t5
	t5 = Triangle(2, t5.getSideB(), t5.getSideC());
	printTriangleDetails("Changed sideA", t5);
	// change 3rd side of t5
	t5 = Triangle(t5.getSideA(), t5.getSideB(), 4);
	printTriangleDetails("Changed sideC", t5);
	Triangle t6;
	// assign new triangle to previous triangle
	t6 = t4;
	printTriangleDetails("Created t6 and assigned t6=t4", t6);
	return (0);
}

/* Purpose: auxiliary function used to print triangle specifications
Parameters: value string and constant reference triangle
Returns: nothing */
void printTriangleDetails(string label, const Triangle& tri)
{
	cout << label << " triangle: [" << tri.getSideA()
		<< ", " << tri.getSideB() << ", " << tri.getSideC()
		<< "]\n  The area of the triangle is "
		<< tri.triangleArea() << "\n";
	if (tri.isRightTriangle())
	{
		cout << "  Triangle is a right triangle\n";
	}
	else
	{
		cout << "  Triangle is not a right triangle\n";
	}
	if (tri.isEquilateralTriangle())
	{
		cout << "  Triangle is an equilateral triangle\n";
	}
	else
	{
		cout << "  Triangle is not an equilateral triangle\n";
	}
	if (tri.isIsoscelesTriangle())
	{
		cout << "  Triangle is an isosceles triangle\n";
	}
	else
	{
		cout << "  Triangle is not an isosceles triangle\n";
	}
	// end of details for this triangle
}