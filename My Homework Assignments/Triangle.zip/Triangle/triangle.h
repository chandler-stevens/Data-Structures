#ifndef TRIANGLE_H
#define TRIANGLE_H

//////////////////////////////////////////////////////////////////
// triangle.h
// type for representing triangles.
class Triangle {
public:
	// set of operations

	// constructors
	// default constructor
	Triangle(void);
	// convert constructor
	Triangle(const double, const double, const double);

	// getters
	// retrieve side a
	double  getSideA(void) const;
	// retrieve side b
	double  getSideB(void) const;
	// retrieve side c
	double  getSideC(void) const;

	// calculate area of triangle using Herod's Method
	double  triangleArea(void) const;

	// check if triangle is pythagorean
	bool  isRightTriangle(void) const;
	// check if triangle is equilateral
	bool  isEquilateralTriangle(void) const;
	// check if triangle is isosceles
	bool  isIsoscelesTriangle(void) const;
private:
	// Set of values

	// Triangle sides
	double m_a, m_b, m_c;
};

#endif